<html>
<head>
	<title>do-while Loop</title>
</head>
<body>
<?php 
	$result = 1;
	do {
		echo $result . "<br />";
		$result++;
	}
	while ($result < 10);
?>
</body>
</html>
