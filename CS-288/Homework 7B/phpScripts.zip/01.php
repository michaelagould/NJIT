<html>
<head>
	<title>Starting PHP</title>
</head>
<body>
<?php echo "Hello World"; ?>
</body>
</html>
