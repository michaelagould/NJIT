<html>
<head>
	<title>for Loop</title>
</head>
<body>
<?php 
	$num = 9;
	echo 'The following are the numbers from 1 to ' . $num . '<br />';
	for ($counter = 1; $counter <= $num; $counter++)
		echo '$counter is ' . $counter . '<br />';
?>
</body>
</html>
