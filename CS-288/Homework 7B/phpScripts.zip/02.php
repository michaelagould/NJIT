<html>
<head>
	<title>Using Variables</title>
</head>
<body>
<?php
	$name='John';
	echo "Hello $name!";
    echo "<br />";
    echo 'Hello $name';
?>
</body>
</html>
