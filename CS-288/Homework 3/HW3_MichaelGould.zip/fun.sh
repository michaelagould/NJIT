#!/bin/bash

this=5
that=4
thut=0

echo $this
echo $that
thut=((this + that))
echo $thut